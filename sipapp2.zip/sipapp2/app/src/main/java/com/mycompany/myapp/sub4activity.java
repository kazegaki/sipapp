package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;

public class sub4activity extends Activity
{
	DataBaseHelper myDb;
    EditText txtUsername, txtPassword;
    Button btnClickDaftar;

    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sub4);
		myDb = new DataBaseHelper(this);
        txtUsername = (EditText) findViewById(R.id.usernameEditText1);
        txtPassword = (EditText) findViewById(R.id.passwordEditText2);
        btnClickDaftar = (Button) findViewById(R.id.daftarButton1);
        btnClickDaftar.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					ClickDaftar();
				}
			});

    }
	private void ClickDaftar() {
        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();
        Boolean result = myDb.insertData(username, password);
        if (result == true) {
            Toast.makeText(this, "Pendaftaran Berhasil", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Pendaftaran Gagal", Toast.LENGTH_SHORT).show();
        }
    }
}
