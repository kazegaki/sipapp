
package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.widget.AdapterView.*;

public class sub2activity extends Activity
{

    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sub2);
        String[] companies = new String[] { "Andi", "Budi", "Angga",
        	"Yuni", "Rendra", "Sari", "Armi", "Intan", "Juki" };

        ListAdapter adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, companies);
        ListView listView = (ListView) findViewById(R.id.sub1mainListView1);
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> l, View v, int position, long id)
				{
					String s = (String)l.getItemAtPosition(position);
					Toast.makeText(sub2activity.this,s,Toast.LENGTH_SHORT).show();
				}
			});
    }
}
