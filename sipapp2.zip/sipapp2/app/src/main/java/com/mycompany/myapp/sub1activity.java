package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.view.*;

public class sub1activity extends Activity
{

    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);

        setContentView(R.layout.sub1);
    }
	public void onSub2ButtonClick(View view) 
    {
    	Intent intent = new Intent(this,sub2activity.class);
		startActivity(intent);

	}
	public void onSub3ButtonClick(View view) 
    {
    	Intent intent = new Intent(this,sub3activity.class);
		startActivity(intent);

	}
	}

