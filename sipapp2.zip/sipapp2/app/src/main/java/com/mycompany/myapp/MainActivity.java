package com.mycompany.myapp;

import android.app.*;
import android.os.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.database.*;


public class MainActivity extends Activity 
{
	DataBaseHelper myDb;
	TextView txtUsername,txtPassword;
    Button btnClick;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
	
	public void onSub1ButtonClick(View view) 
    {
		
		myDb = new DataBaseHelper(this);
        
       // btnClick = (Button) findViewById(R.id.mainButton1);
		//Toast.makeText(this,"Login",Toast.LENGTH_SHORT).show();
     //   btnClick.setOnClickListener(new View.OnClickListener() {
			//	@Override
			//	public void onClick(View v) {
		//			ClickLogin();
					
		//		}
		//	});

		
		txtUsername = (TextView) findViewById(R.id.mainEditText1);
		String username1 = txtUsername.getText().toString();
		txtPassword = (TextView) findViewById(R.id.mainEditText2);
		String password1 = txtPassword.getText().toString();

        Cursor res = myDb.getAllData();
        //StringBuffer stringBuffer = new StringBuffer();
        if(res!=null && res.getCount()>0){
			Toast.makeText(this,"Login",Toast.LENGTH_SHORT).show();
            while (res.moveToNext()){
				if(username1.equals(res.getString(1)) && password1.equals(res.getString(2))) 
				{res=null;
					//Toast.makeText(this,"Login Berhasil",Toast.LENGTH_SHORT).show();
					//Intent intent = new Intent(this,sub1activity.class);
					//startActivity(intent);
					//finish();

				}else{}
            }
        }else{
            Toast.makeText(this,"Login Gagal",Toast.LENGTH_SHORT).show();
        }

    }
    private void ClickLogin() {

    }	
	public void onDaftarButtonClick(View view) 
    {
    	Intent intent = new Intent(this,sub4activity.class);
		startActivity(intent);

	}
	
}
